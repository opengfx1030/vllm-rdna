# EPLB final qualification: r1

result: qualified
base: /home/chenco_adm/w4a8_runs/leapquant/tree-eplb-base (b56907c4339779d2076f0886532833689aec93ec)
head: /home/chenco_adm/w4a8_runs/leapquant/tree-eplb-final-2ea7a364848c (2ea7a364848c05f28ecd73a593717a0728157a2d)
tools: 2ea7a364848c05f28ecd73a593717a0728157a2d
receipt exit: 0

| boot | role | kind | rc | faults | cells | max C | ok |
|---|---|---|---|---|---|---|---|
| XA | base | exact | 0 | 0 | 2 | 67.0 | yes |
| XB | head | exact | 0 | 0 | 2 | 70.0 | yes |
| A1 | base | speed | 0 | 0 | 8 | 84.0 | yes |
| B1 | head | speed | 0 | 0 | 8 | 84.0 | yes |
| B2 | head | speed | 0 | 0 | 8 | 84.0 | yes |
| A2 | base | speed | 0 | 0 | 8 | 83.0 | yes |

Receipt gates: exact=PASS, quality=NOT RUN, overlap=PASS, stall=PASS

Speed labels are reported, never gated:
- | speed | 2 cells no measurable difference, 3 win, 3 REGRESSION, 0 invalid |
- | 1k/512 c=4 | 16 | +0.3 % (regression) | -0.0 % | +0.0 % | +0.0 % | -0.9 % (win) | -83.9 % (win) | -6.8 % (regression) | -7.0 % (regression) | REGRESSION |
- | 16k/1k c=8 | 32 | +4.2 % | -0.0 % | +0.1 % | +0.0 % | -0.9 % (win) | -0.3 % (win) | -1.9 % (regression) | -1.9 % | REGRESSION |
- | 32k/2k c=4 | 16 | +0.6 % (regression) | -0.1 % (win) | +0.9 % | +0.1 % (win) | -0.2 % | -0.1 % | -0.7 % | -0.6 % | REGRESSION |
- Each figure is the head mean against the base mean (for TTFT and ITL a negative number is faster). `win` and `REGRESSION` apply the ABBA rule: the verdict needs both head runs on the same side of both base runs.
