## RDNA receipt: 2ea7a36484 against b56907c433

| gate | result |
|---|---|
| token-exact | PASS |
| quality | NOT RUN |
| overlap | PASS |
| stall, hard gate | PASS |
| stall, relative metrics | ABBA: 0 worse, 3 better, 12 no measurable difference (reported, never fails the run) |
| speed | 2 cells no measurable difference, 3 win, 3 REGRESSION, 0 invalid |
| added syncs and launches | 5 lines to review (4 in the per-step path) |
| boots | all exited 0 |

### Environment

|  | base | head |
|---|---|---|
| tree | `/home/chenco_adm/w4a8_runs/leapquant/tree-eplb-base` | `/home/chenco_adm/w4a8_runs/leapquant/tree-eplb-final-2ea7a364848c` |
| git SHA | `b56907c4339779d2076f0886532833689aec93ec` | `2ea7a364848c05f28ecd73a593717a0728157a2d` |
| _rocm_C.abi3.so md5 | `22fc15fb782184ae0f5db6805c5664a9` | `7767169d3645837dd3b31cba0b6a0754` |
| venv | `/home/chenco_adm/Apps/vllm/venv-7.14.0_0.32.0` | `/home/chenco_adm/Apps/vllm/venv-7.14.0_0.32.0` |
| torch / ROCm (HIP) | `2.12.0+rocm7.14.0` / `7.14.60850` | `2.12.0+rocm7.14.0` / `7.14.60850` |

|  |  |
|---|---|
| recipe | `flashnext-mtp2` |
| recipe overrides | `none` |
| model | `/home/chenco_adm/.cache/huggingface/hub/models--wtdcode--Qwen3.8-Flash-Next-AWQ-W4A16/snapshots/0939125b929543a783ce700c90e36dd1a575c00c` |
| model revision | 0939125b929543a783ce700c90e36dd1a575c00c |
| model config.json sha256 | 316307706e38b7db23ecb6a94b1343d8846b52ddb65a217b18c6e242eab20fe9 |
| mode | `MODE=abba` |
| host / kernel | par1-cs25 / 7.1.7-100.p2p_post7.fc43.x86_64 |
| date (UTC) | 2026-11-18 04:17:18 |
| compilation config | `{"mode":3,"cudagraph_mode":"FULL_AND_PIECEWISE","cudagraph_capture_sizes":[3,6,12,24],"compile_ranges_endpoints":[]}` |
| tools tree | `/home/chenco_adm/w4a8_runs/leapquant/tree-eplb-final-2ea7a364848c` @ 2ea7a364848c05f28ecd73a593717a0728157a2d |
| speed cells | `1024:512:1 1024:512:4 1024:512:8 16384:1024:1 16384:1024:4 16384:1024:8 32768:2048:1 32768:2048:4` |
| exactness cells | `1024:128:1:4 16384:128:1:2` |

| HIP | GPU | gfx | PCI bus | memory |
|---|---|---|---|---|
| 2 | AMD Radeon Pro V620 | gfx1030 | d9 | 30.0 GiB |
| 3 | AMD Radeon Pro V620 | gfx1030 | dc | 30.0 GiB |
| 4 | AMD Radeon Pro V620 | gfx1030 | df | 30.0 GiB |
| 5 | AMD Radeon Pro V620 | gfx1030 | e2 | 30.0 GiB |

### Change class and reach

- Change class: opt-in RDNA2 EPLB/Mono; flag-off compatibility
- Platforms run: gfx1030 (4 GPUs)
- Platforms not run: Other runtime architectures; stationary EPLB; live K2 injection
- Paths and callers reached, as the author states them: gfx1030 V620 TP4 MTP2 F&P; independent base/head extensions
- Launch plans of the two trees (tree paths masked): identical
- Paths the servers selected (marker lines of serve.log, numbers masked): the same for base and head

### Exactness

Greedy output hashes, base against head, with `VLLM_RDNA2_MOE_DETERMINISTIC=1`; concurrent replies against their solo runs (`concurrency_probe.py`).

| check | result |
|---|---|
| greedy outputs hashed | 26 compared |
| equal base vs head | 26 of 26 |
| not in both boots | none |
| differing | none |
| repeat of a solo request differs (base, head) | 0, 0 |
| concurrency probe, base | PASS: 0 failing, 11 near-tie, 34 identical of 48 |
| concurrency probe, head | PASS: 0 failing, 12 near-tie, 33 identical of 48 |

### Quality

`topk_kl.py`: head against base, with base against a second base boot as the floor (head KL within the floor's upper CI bound, head top-1 agreement above the floor's lower CI bound); `quality_ab.py`: PPL rise at most 2 %; the concurrency probe and the greedy probes pass.

Not run.

### Speed

Production mode of the recipe, greedy (`--temperature 0`), `--ignore-eos`, seed 12345, prefix cache reset before every cell, capture-ladder warm-up after boot; a KFD eviction invalidates a cell.

Boots in order: A1 (base), B1 (head), B2 (head), A2 (base).

| cell | requests | TTFT p50 | TTFT p99 | prefill per request | prefill aggregate | ITL p50 | ITL p99 | decode per request | output aggregate | verdict |
|---|---|---|---|---|---|---|---|---|---|---|
| 1k/512 c=1 | 4 | -0.1 % | -0.2 % | +0.2 % | +0.2 % | -0.1 % | +0.2 % | -2.5 % | -2.3 % | no measurable difference |
| 1k/512 c=4 | 16 | +0.3 % (regression) | -0.0 % | +0.0 % | +0.0 % | -0.9 % (win) | -83.9 % (win) | -6.8 % (regression) | -7.0 % (regression) | REGRESSION |
| 1k/512 c=8 | 32 | -0.0 % | +0.1 % | +1.8 % | -0.1 % | -0.5 % (win) | +0.0 % | +0.3 % | +1.5 % | win |
| 16k/1k c=1 | 4 | -0.0 % | -0.1 % | +0.0 % | +0.1 % | +0.4 % | +0.5 % | +13.2 % | +9.4 % | no measurable difference |
| 16k/1k c=4 | 16 | -5.4 % | -0.0 % | +0.5 % | +0.0 % | -0.6 % (win) | -0.1 % (win) | -0.1 % | +1.4 % | win |
| 16k/1k c=8 | 32 | +4.2 % | -0.0 % | +0.1 % | +0.0 % | -0.9 % (win) | -0.3 % (win) | -1.9 % (regression) | -1.9 % | REGRESSION |
| 32k/2k c=1 | 4 | -0.0 % | +0.0 % | +0.0 % (win) | -0.0 % | +0.2 % | +0.0 % | +0.9 % | +0.6 % | win |
| 32k/2k c=4 | 16 | +0.6 % (regression) | -0.1 % (win) | +0.9 % | +0.1 % (win) | -0.2 % | -0.1 % | -0.7 % | -0.6 % | REGRESSION |

Each figure is the head mean against the base mean (for TTFT and ITL a negative number is faster). `win` and `REGRESSION` apply the ABBA rule: the verdict needs both head runs on the same side of both base runs.

<details><summary>Every figure of every boot</summary>

| cell | metric | A1 base | B1 head | B2 head | A2 base | head vs base | result |
|---|---|---|---|---|---|---|---|
| 1k/512 c=1 | TTFT p50 (s) | 0.40 | 0.40 | 0.40 | 0.40 | -0.1 % |  |
| 1k/512 c=1 | TTFT p99 (s) | 0.41 | 0.41 | 0.41 | 0.41 | -0.2 % |  |
| 1k/512 c=1 | prefill per request (tok/s) | 2562.3 | 2558.0 | 2563.4 | 2548.3 | +0.2 % |  |
| 1k/512 c=1 | prefill aggregate (tok/s) | 2522.5 | 2525.5 | 2516.9 | 2511.6 | +0.2 % |  |
| 1k/512 c=1 | ITL p50 (ms) | 22.6 | 22.5 | 22.6 | 22.5 | -0.1 % |  |
| 1k/512 c=1 | ITL p99 (ms) | 23.1 | 23.0 | 23.1 | 23.0 | +0.2 % |  |
| 1k/512 c=1 | decode per request (tok/s) | 87.98 | 72.70 | 86.83 | 75.62 | -2.5 % |  |
| 1k/512 c=1 | output aggregate (tok/s) | 82.47 | 68.92 | 81.46 | 71.51 | -2.3 % |  |
| 1k/512 c=4 | TTFT p50 (s) | 0.52 | 0.52 | 0.52 | 0.52 | +0.3 % | regression |
| 1k/512 c=4 | TTFT p99 (s) | 1.57 | 1.57 | 1.57 | 1.57 | -0.0 % |  |
| 1k/512 c=4 | prefill per request (tok/s) | 1513.2 | 1511.9 | 1512.7 | 1511.1 | +0.0 % |  |
| 1k/512 c=4 | prefill aggregate (tok/s) | 2608.9 | 2606.8 | 2610.2 | 2606.9 | +0.0 % |  |
| 1k/512 c=4 | ITL p50 (ms) | 35.8 | 35.6 | 35.4 | 35.8 | -0.9 % | win |
| 1k/512 c=4 | ITL p99 (ms) | 382.8 | 61.8 | 61.7 | 384.4 | -83.9 % | win |
| 1k/512 c=4 | decode per request (tok/s) | 54.92 | 50.65 | 52.30 | 55.49 | -6.8 % | regression |
| 1k/512 c=4 | output aggregate (tok/s) | 196.51 | 181.14 | 184.28 | 196.63 | -7.0 % | regression |
| 1k/512 c=8 | TTFT p50 (s) | 0.54 | 0.55 | 0.54 | 0.54 | -0.0 % |  |
| 1k/512 c=8 | TTFT p99 (s) | 3.14 | 3.14 | 3.14 | 3.13 | +0.1 % |  |
| 1k/512 c=8 | prefill per request (tok/s) | 1069.0 | 1081.2 | 1121.4 | 1094.2 | +1.8 % |  |
| 1k/512 c=8 | prefill aggregate (tok/s) | 2612.4 | 2609.8 | 2612.6 | 2613.2 | -0.1 % |  |
| 1k/512 c=8 | ITL p50 (ms) | 46.1 | 46.0 | 46.0 | 46.3 | -0.5 % | win |
| 1k/512 c=8 | ITL p99 (ms) | 384.5 | 384.9 | 384.4 | 384.6 | +0.0 % |  |
| 1k/512 c=8 | decode per request (tok/s) | 38.08 | 38.18 | 38.05 | 37.90 | +0.3 % |  |
| 1k/512 c=8 | output aggregate (tok/s) | 269.21 | 267.51 | 272.73 | 263.30 | +1.5 % |  |
| 16k/1k c=1 | TTFT p50 (s) | 5.95 | 5.96 | 5.96 | 5.97 | -0.0 % |  |
| 16k/1k c=1 | TTFT p99 (s) | 5.97 | 5.97 | 5.98 | 5.99 | -0.1 % |  |
| 16k/1k c=1 | prefill per request (tok/s) | 2752.6 | 2750.7 | 2749.5 | 2746.0 | +0.0 % |  |
| 16k/1k c=1 | prefill aggregate (tok/s) | 2744.1 | 2744.1 | 2741.0 | 2733.8 | +0.1 % |  |
| 16k/1k c=1 | ITL p50 (ms) | 23.0 | 23.0 | 23.0 | 22.8 | +0.4 % |  |
| 16k/1k c=1 | ITL p99 (ms) | 23.6 | 23.5 | 23.7 | 23.5 | +0.5 % |  |
| 16k/1k c=1 | decode per request (tok/s) | 114.29 | 94.93 | 113.99 | 70.28 | +13.2 % |  |
| 16k/1k c=1 | output aggregate (tok/s) | 68.71 | 61.20 | 68.57 | 49.89 | +9.4 % |  |
| 16k/1k c=4 | TTFT p50 (s) | 7.97 | 6.90 | 7.15 | 6.88 | -5.4 % |  |
| 16k/1k c=4 | TTFT p99 (s) | 24.18 | 24.20 | 24.19 | 24.22 | -0.0 % |  |
| 16k/1k c=4 | prefill per request (tok/s) | 1576.4 | 1673.5 | 1595.7 | 1678.0 | +0.5 % |  |
| 16k/1k c=4 | prefill aggregate (tok/s) | 2710.1 | 2708.5 | 2708.8 | 2705.9 | +0.0 % |  |
| 16k/1k c=4 | ITL p50 (ms) | 37.1 | 36.9 | 36.9 | 37.1 | -0.6 % | win |
| 16k/1k c=4 | ITL p99 (ms) | 421.2 | 421.1 | 421.0 | 421.6 | -0.1 % | win |
| 16k/1k c=4 | decode per request (tok/s) | 34.38 | 31.94 | 34.76 | 32.37 | -0.1 % |  |
| 16k/1k c=4 | output aggregate (tok/s) | 100.23 | 96.13 | 102.25 | 95.44 | +1.4 % |  |
| 16k/1k c=8 | TTFT p50 (s) | 7.71 | 7.14 | 8.52 | 7.32 | +4.2 % |  |
| 16k/1k c=8 | TTFT p99 (s) | 50.33 | 50.35 | 50.32 | 50.38 | -0.0 % |  |
| 16k/1k c=8 | prefill per request (tok/s) | 1216.2 | 1219.2 | 1179.3 | 1179.9 | +0.1 % |  |
| 16k/1k c=8 | prefill aggregate (tok/s) | 2604.2 | 2603.4 | 2605.0 | 2601.9 | +0.0 % |  |
| 16k/1k c=8 | ITL p50 (ms) | 47.7 | 47.3 | 47.1 | 47.5 | -0.9 % | win |
| 16k/1k c=8 | ITL p99 (ms) | 431.4 | 430.8 | 430.8 | 432.3 | -0.3 % | win |
| 16k/1k c=8 | decode per request (tok/s) | 18.05 | 17.43 | 17.88 | 17.96 | -1.9 % | regression |
| 16k/1k c=8 | output aggregate (tok/s) | 112.80 | 106.76 | 113.08 | 111.39 | -1.9 % |  |
| 32k/2k c=1 | TTFT p50 (s) | 12.13 | 12.11 | 12.12 | 12.12 | -0.0 % |  |
| 32k/2k c=1 | TTFT p99 (s) | 12.16 | 12.16 | 12.17 | 12.16 | +0.0 % |  |
| 32k/2k c=1 | prefill per request (tok/s) | 2710.5 | 2712.2 | 2710.9 | 2710.9 | +0.0 % | win |
| 32k/2k c=1 | prefill aggregate (tok/s) | 2694.3 | 2694.9 | 2691.8 | 2694.2 | -0.0 % |  |
| 32k/2k c=1 | ITL p50 (ms) | 23.0 | 23.1 | 23.0 | 23.1 | +0.2 % |  |
| 32k/2k c=1 | ITL p99 (ms) | 23.6 | 23.6 | 23.6 | 23.7 | +0.0 % |  |
| 32k/2k c=1 | decode per request (tok/s) | 91.98 | 108.15 | 93.68 | 108.11 | +0.9 % |  |
| 32k/2k c=1 | output aggregate (tok/s) | 59.63 | 66.05 | 60.34 | 66.02 | +0.6 % |  |
| 32k/2k c=4 | TTFT p50 (s) | 14.19 | 14.28 | 14.29 | 14.19 | +0.6 % | regression |
| 32k/2k c=4 | TTFT p99 (s) | 50.37 | 50.29 | 50.35 | 50.38 | -0.1 % | win |
| 32k/2k c=4 | prefill per request (tok/s) | 1604.0 | 1591.1 | 1665.7 | 1622.6 | +0.9 % |  |
| 32k/2k c=4 | prefill aggregate (tok/s) | 2602.0 | 2606.3 | 2603.5 | 2601.5 | +0.1 % | win |
| 32k/2k c=4 | ITL p50 (ms) | 37.6 | 37.2 | 37.7 | 37.5 | -0.2 % |  |
| 32k/2k c=4 | ITL p99 (ms) | 435.0 | 434.3 | 435.7 | 435.4 | -0.1 % |  |
| 32k/2k c=4 | decode per request (tok/s) | 34.23 | 32.68 | 32.98 | 31.92 | -0.7 % |  |
| 32k/2k c=4 | output aggregate (tok/s) | 99.58 | 95.70 | 98.05 | 95.27 | -0.6 % |  |

</details>

#### Speculative acceptance length

| cell | A1 base | B1 head | B2 head | A2 base | source |
|---|---|---|---|---|---|
| 1k/512 c=1 | 1.988 | 1.637 | 1.964 | 1.706 | bench |
| 1k/512 c=4 | 2.160 | 1.963 | 2.013 | 2.174 | bench |
| 1k/512 c=8 | 2.040 | 2.045 | 2.040 | 2.029 | bench |
| 16k/1k c=1 | 2.629 | 2.183 | 2.624 | 1.606 | bench |
| 16k/1k c=4 | 2.449 | 2.189 | 2.504 | 2.236 | bench |
| 16k/1k c=8 | 2.272 | 2.028 | 2.168 | 2.197 | bench |
| 32k/2k c=1 | 2.112 | 2.494 | 2.154 | 2.491 | bench |
| 32k/2k c=4 | 2.589 | 2.351 | 2.477 | 2.282 | bench |

### Concurrency and stalls

#### Overlap

| cell | boot | requests timed | most generating at once | most in flight | output tok/s | c=1 output tok/s | scaling | result |
|---|---|---|---|---|---|---|---|---|
| 1k/512 c=4 | A1 base | 16 of 16 | 4 | 4 | 196.51 | 82.47 | x2.38 | PASS |
| 1k/512 c=4 | B1 head | 16 of 16 | 4 | 4 | 181.14 | 68.92 | x2.63 | PASS |
| 1k/512 c=4 | B2 head | 16 of 16 | 4 | 4 | 184.28 | 81.46 | x2.26 | PASS |
| 1k/512 c=4 | A2 base | 16 of 16 | 4 | 4 | 196.63 | 71.51 | x2.75 | PASS |
| 1k/512 c=8 | A1 base | 32 of 32 | 8 | 8 | 269.21 | 82.47 | x3.26 | PASS |
| 1k/512 c=8 | B1 head | 32 of 32 | 8 | 8 | 267.51 | 68.92 | x3.88 | PASS |
| 1k/512 c=8 | B2 head | 32 of 32 | 8 | 8 | 272.73 | 81.46 | x3.35 | PASS |
| 1k/512 c=8 | A2 base | 32 of 32 | 8 | 8 | 263.30 | 71.51 | x3.68 | PASS |
| 16k/1k c=4 | A1 base | 16 of 16 | 4 | 4 | 100.23 | 68.71 | x1.46 | PASS |
| 16k/1k c=4 | B1 head | 16 of 16 | 4 | 4 | 96.13 | 61.20 | x1.57 | PASS |
| 16k/1k c=4 | B2 head | 16 of 16 | 4 | 4 | 102.25 | 68.57 | x1.49 | PASS |
| 16k/1k c=4 | A2 base | 16 of 16 | 4 | 4 | 95.44 | 49.89 | x1.91 | PASS |
| 16k/1k c=8 | A1 base | 32 of 32 | 8 | 8 | 112.80 | 68.71 | x1.64 | PASS |
| 16k/1k c=8 | B1 head | 32 of 32 | 8 | 8 | 106.76 | 61.20 | x1.74 | PASS |
| 16k/1k c=8 | B2 head | 32 of 32 | 8 | 8 | 113.08 | 68.57 | x1.65 | PASS |
| 16k/1k c=8 | A2 base | 32 of 32 | 8 | 8 | 111.39 | 49.89 | x2.23 | PASS |
| 32k/2k c=4 | A1 base | 16 of 16 | 4 | 4 | 99.58 | 59.63 | x1.67 | PASS |
| 32k/2k c=4 | B1 head | 16 of 16 | 4 | 4 | 95.70 | 66.05 | x1.45 | PASS |
| 32k/2k c=4 | B2 head | 16 of 16 | 4 | 4 | 98.05 | 60.34 | x1.62 | PASS |
| 32k/2k c=4 | A2 base | 16 of 16 | 4 | 4 | 95.27 | 66.02 | x1.44 | PASS |

A cell fails when no two of its requests generate at the same time (first token to last token), or when its aggregate output tok/s is not above the c=1 cell of the same shape on the same boot. Times are seconds from the first submit of the cell. The gate is the head boots.

<details><summary>1k/512 c=4, A1 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.40 | 8.31 | 512 |
| 1 | 0.00 | 1.14 | 7.65 | 512 |
| 2 | 0.00 | 1.53 | 14.91 | 512 |
| 3 | 0.00 | 1.58 | 10.71 | 512 |
| 4 | 7.65 | 8.16 | 17.95 | 512 |
| 5 | 8.31 | 8.82 | 17.25 | 512 |
| 6 | 10.71 | 11.22 | 19.83 | 512 |
| 7 | 14.91 | 15.43 | 28.26 | 512 |
| 8 | 17.25 | 17.77 | 24.82 | 512 |
| 9 | 17.95 | 18.46 | 29.11 | 512 |
| 10 | 19.83 | 20.35 | 33.06 | 512 |
| 11 | 24.82 | 25.34 | 34.41 | 512 |
| 12 | 28.26 | 28.77 | 38.38 | 512 |
| 13 | 29.11 | 29.63 | 38.83 | 512 |
| 14 | 33.06 | 33.58 | 40.80 | 512 |
| 15 | 34.41 | 34.94 | 41.69 | 512 |

</details>

<details><summary>1k/512 c=4, B1 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.40 | 18.67 | 512 |
| 1 | 0.00 | 1.14 | 8.85 | 512 |
| 2 | 0.00 | 1.53 | 13.76 | 512 |
| 3 | 0.00 | 1.58 | 9.86 | 512 |
| 4 | 8.85 | 9.36 | 16.81 | 512 |
| 5 | 9.86 | 10.37 | 19.22 | 512 |
| 6 | 13.76 | 14.28 | 27.20 | 512 |
| 7 | 16.81 | 17.33 | 32.28 | 512 |
| 8 | 18.67 | 19.19 | 26.66 | 512 |
| 9 | 19.23 | 19.74 | 28.10 | 512 |
| 10 | 26.66 | 27.17 | 40.38 | 512 |
| 11 | 27.20 | 27.71 | 36.45 | 512 |
| 12 | 28.10 | 28.61 | 38.15 | 512 |
| 13 | 32.28 | 32.80 | 42.03 | 512 |
| 14 | 36.45 | 36.97 | 44.63 | 512 |
| 15 | 38.15 | 38.67 | 45.22 | 512 |

</details>

<details><summary>1k/512 c=4, B2 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.40 | 13.08 | 512 |
| 1 | 0.00 | 1.15 | 8.15 | 512 |
| 2 | 0.00 | 1.58 | 14.89 | 512 |
| 3 | 0.00 | 1.53 | 10.35 | 512 |
| 4 | 8.15 | 8.66 | 16.46 | 512 |
| 5 | 10.35 | 10.86 | 19.54 | 512 |
| 6 | 13.08 | 13.59 | 28.89 | 512 |
| 7 | 14.90 | 15.41 | 23.97 | 512 |
| 8 | 16.46 | 16.98 | 28.16 | 512 |
| 9 | 19.54 | 20.06 | 31.11 | 512 |
| 10 | 23.97 | 24.48 | 36.32 | 512 |
| 11 | 28.16 | 28.68 | 37.85 | 512 |
| 12 | 28.89 | 29.40 | 39.25 | 512 |
| 13 | 31.11 | 31.63 | 40.67 | 512 |
| 14 | 36.32 | 36.84 | 42.77 | 512 |
| 15 | 37.85 | 38.37 | 44.45 | 512 |

</details>

<details><summary>1k/512 c=4, A2 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.40 | 10.50 | 512 |
| 1 | 0.00 | 1.58 | 8.70 | 512 |
| 2 | 0.00 | 1.14 | 12.93 | 512 |
| 3 | 0.00 | 1.53 | 11.18 | 512 |
| 4 | 8.70 | 9.21 | 17.39 | 512 |
| 5 | 10.50 | 11.01 | 18.69 | 512 |
| 6 | 11.18 | 11.69 | 24.46 | 512 |
| 7 | 12.93 | 13.45 | 27.17 | 512 |
| 8 | 17.39 | 17.91 | 24.92 | 512 |
| 9 | 18.70 | 19.21 | 28.09 | 512 |
| 10 | 24.46 | 24.98 | 33.47 | 512 |
| 11 | 24.92 | 25.46 | 34.85 | 512 |
| 12 | 27.17 | 27.69 | 37.89 | 512 |
| 13 | 28.09 | 28.61 | 37.96 | 512 |
| 14 | 33.47 | 33.98 | 40.66 | 512 |
| 15 | 34.85 | 35.37 | 41.66 | 512 |

</details>

<details><summary>1k/512 c=8, A1 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.42 | 12.90 | 512 |
| 1 | 0.00 | 1.15 | 11.23 | 512 |
| 2 | 0.00 | 1.92 | 16.23 | 512 |
| 3 | 0.00 | 1.54 | 17.48 | 512 |
| 4 | 0.00 | 2.31 | 12.90 | 512 |
| 5 | 0.00 | 2.70 | 23.80 | 512 |
| 6 | 0.00 | 3.09 | 20.25 | 512 |
| 7 | 0.00 | 3.16 | 21.12 | 512 |
| 8 | 11.24 | 11.77 | 21.76 | 512 |
| 9 | 12.90 | 13.76 | 26.54 | 512 |
| 10 | 12.90 | 13.82 | 32.79 | 512 |
| 11 | 16.23 | 16.76 | 32.20 | 512 |
| 12 | 17.48 | 18.02 | 30.36 | 512 |
| 13 | 20.25 | 20.79 | 34.66 | 512 |
| 14 | 21.12 | 21.67 | 33.48 | 512 |
| 15 | 21.76 | 22.31 | 35.63 | 512 |
| 16 | 23.80 | 24.35 | 36.36 | 512 |
| 17 | 26.54 | 27.09 | 38.85 | 512 |
| 18 | 30.36 | 30.90 | 43.89 | 512 |
| 19 | 32.20 | 32.75 | 46.16 | 512 |
| 20 | 32.79 | 33.33 | 47.30 | 512 |
| 21 | 33.48 | 34.02 | 44.87 | 512 |
| 22 | 34.66 | 35.20 | 47.26 | 512 |
| 23 | 35.63 | 36.17 | 55.79 | 512 |
| 24 | 36.36 | 36.90 | 56.24 | 512 |
| 25 | 38.85 | 39.39 | 49.02 | 512 |
| 26 | 43.89 | 44.42 | 56.20 | 512 |
| 27 | 44.87 | 45.40 | 56.45 | 512 |
| 28 | 46.16 | 46.70 | 57.59 | 512 |
| 29 | 47.26 | 48.13 | 60.86 | 512 |
| 30 | 47.30 | 48.20 | 58.17 | 512 |
| 31 | 49.02 | 49.56 | 58.80 | 512 |

</details>

<details><summary>1k/512 c=8, B1 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.40 | 12.08 | 512 |
| 1 | 0.00 | 1.15 | 12.61 | 512 |
| 2 | 0.00 | 1.54 | 19.53 | 512 |
| 3 | 0.00 | 1.92 | 15.43 | 512 |
| 4 | 0.00 | 3.10 | 12.65 | 512 |
| 5 | 0.00 | 2.31 | 22.27 | 512 |
| 6 | 0.00 | 2.71 | 20.87 | 512 |
| 7 | 0.00 | 3.16 | 17.57 | 512 |
| 8 | 12.08 | 12.61 | 23.25 | 512 |
| 9 | 12.61 | 13.47 | 23.94 | 512 |
| 10 | 12.65 | 13.53 | 27.39 | 512 |
| 11 | 15.43 | 15.96 | 30.92 | 512 |
| 12 | 17.57 | 18.11 | 29.27 | 512 |
| 13 | 19.53 | 20.08 | 38.49 | 512 |
| 14 | 20.87 | 21.42 | 33.06 | 512 |
| 15 | 22.27 | 22.82 | 35.58 | 512 |
| 16 | 23.25 | 23.80 | 34.80 | 512 |
| 17 | 23.94 | 24.48 | 38.58 | 512 |
| 18 | 27.39 | 27.93 | 39.76 | 512 |
| 19 | 29.27 | 29.81 | 44.21 | 512 |
| 20 | 30.92 | 31.46 | 44.98 | 512 |
| 21 | 33.06 | 33.61 | 45.45 | 512 |
| 22 | 34.80 | 35.34 | 57.50 | 512 |
| 23 | 35.58 | 36.12 | 48.44 | 512 |
| 24 | 38.49 | 39.03 | 58.43 | 512 |
| 25 | 38.58 | 39.48 | 51.03 | 512 |
| 26 | 39.76 | 40.31 | 52.12 | 512 |
| 27 | 44.21 | 44.75 | 55.14 | 512 |
| 28 | 44.98 | 45.52 | 55.81 | 512 |
| 29 | 45.45 | 46.01 | 61.25 | 512 |
| 30 | 48.44 | 48.98 | 58.03 | 512 |
| 31 | 51.03 | 51.57 | 60.36 | 512 |

</details>

<details><summary>1k/512 c=8, B2 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.40 | 18.58 | 512 |
| 1 | 0.00 | 1.15 | 10.64 | 512 |
| 2 | 0.00 | 1.92 | 19.12 | 512 |
| 3 | 0.00 | 1.53 | 22.16 | 512 |
| 4 | 0.00 | 2.31 | 14.33 | 512 |
| 5 | 0.00 | 2.70 | 12.93 | 512 |
| 6 | 0.00 | 3.09 | 17.91 | 512 |
| 7 | 0.00 | 3.16 | 20.08 | 512 |
| 8 | 10.64 | 11.17 | 21.10 | 512 |
| 9 | 12.93 | 13.45 | 25.78 | 512 |
| 10 | 14.33 | 14.86 | 27.07 | 512 |
| 11 | 17.91 | 18.44 | 31.27 | 512 |
| 12 | 18.58 | 19.12 | 32.51 | 512 |
| 13 | 19.12 | 19.66 | 45.09 | 512 |
| 14 | 20.08 | 20.62 | 33.10 | 512 |
| 15 | 21.10 | 21.64 | 37.66 | 512 |
| 16 | 22.16 | 22.71 | 34.37 | 512 |
| 17 | 25.78 | 26.33 | 42.60 | 512 |
| 18 | 27.07 | 27.61 | 38.89 | 512 |
| 19 | 31.27 | 31.82 | 51.75 | 512 |
| 20 | 32.51 | 33.05 | 44.23 | 512 |
| 21 | 33.10 | 33.64 | 46.24 | 512 |
| 22 | 34.37 | 34.91 | 45.76 | 512 |
| 23 | 37.66 | 38.20 | 50.12 | 512 |
| 24 | 38.89 | 39.43 | 57.59 | 512 |
| 25 | 42.60 | 43.14 | 53.64 | 512 |
| 26 | 44.23 | 44.77 | 56.57 | 512 |
| 27 | 45.09 | 45.63 | 56.99 | 512 |
| 28 | 45.76 | 46.31 | 56.57 | 512 |
| 29 | 46.24 | 46.81 | 58.14 | 512 |
| 30 | 50.12 | 50.67 | 59.39 | 512 |
| 31 | 51.75 | 52.29 | 60.07 | 512 |

</details>

<details><summary>1k/512 c=8, A2 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 0.40 | 26.20 | 512 |
| 1 | 0.00 | 1.15 | 12.05 | 512 |
| 2 | 0.00 | 1.53 | 20.42 | 512 |
| 3 | 0.00 | 1.92 | 17.27 | 512 |
| 4 | 0.00 | 2.31 | 12.05 | 512 |
| 5 | 0.00 | 3.09 | 13.23 | 512 |
| 6 | 0.00 | 2.70 | 18.21 | 512 |
| 7 | 0.00 | 3.16 | 21.53 | 512 |
| 8 | 12.05 | 12.91 | 23.18 | 512 |
| 9 | 12.05 | 12.97 | 25.30 | 512 |
| 10 | 13.23 | 13.75 | 28.48 | 512 |
| 11 | 17.27 | 17.80 | 30.78 | 512 |
| 12 | 18.21 | 18.75 | 32.25 | 512 |
| 13 | 20.42 | 20.96 | 34.83 | 512 |
| 14 | 21.53 | 22.08 | 33.40 | 512 |
| 15 | 23.18 | 23.73 | 37.24 | 512 |
| 16 | 25.30 | 25.84 | 37.79 | 512 |
| 17 | 26.20 | 26.74 | 40.30 | 512 |
| 18 | 28.48 | 29.02 | 43.22 | 512 |
| 19 | 30.78 | 31.32 | 42.36 | 512 |
| 20 | 32.25 | 32.79 | 44.60 | 512 |
| 21 | 33.40 | 33.95 | 45.98 | 512 |
| 22 | 34.83 | 35.38 | 54.85 | 512 |
| 23 | 37.24 | 37.78 | 49.61 | 512 |
| 24 | 37.79 | 38.33 | 58.69 | 512 |
| 25 | 40.30 | 40.84 | 51.36 | 512 |
| 26 | 42.36 | 42.90 | 54.62 | 512 |
| 27 | 43.22 | 43.77 | 57.58 | 512 |
| 28 | 44.60 | 45.14 | 55.81 | 512 |
| 29 | 45.98 | 46.52 | 58.63 | 512 |
| 30 | 49.61 | 50.16 | 58.99 | 512 |
| 31 | 51.36 | 51.90 | 62.22 | 512 |

</details>

<details><summary>16k/1k c=4, A1 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 6.85 | 38.37 | 1024 |
| 1 | 0.00 | 12.47 | 45.36 | 1024 |
| 2 | 0.00 | 18.89 | 49.99 | 1024 |
| 3 | 0.00 | 25.12 | 59.81 | 1024 |
| 4 | 38.37 | 45.16 | 78.44 | 1024 |
| 5 | 45.36 | 52.46 | 78.48 | 1024 |
| 6 | 49.99 | 58.75 | 95.23 | 1024 |
| 7 | 59.81 | 66.66 | 92.64 | 1024 |
| 8 | 78.44 | 85.52 | 118.15 | 1024 |
| 9 | 78.48 | 91.87 | 130.06 | 1024 |
| 10 | 92.64 | 99.79 | 126.23 | 1024 |
| 11 | 95.23 | 106.13 | 135.46 | 1024 |
| 12 | 118.15 | 125.01 | 163.46 | 1024 |
| 13 | 126.24 | 133.40 | 158.33 | 1024 |
| 14 | 130.06 | 140.04 | 159.55 | 1024 |
| 15 | 135.46 | 146.40 | 161.02 | 1024 |

</details>

<details><summary>16k/1k c=4, B1 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 6.87 | 52.49 | 1024 |
| 1 | 0.00 | 12.48 | 44.14 | 1024 |
| 2 | 0.00 | 25.13 | 52.59 | 1024 |
| 3 | 0.00 | 18.93 | 37.33 | 1024 |
| 4 | 37.33 | 44.14 | 76.04 | 1024 |
| 5 | 44.14 | 50.95 | 102.75 | 1024 |
| 6 | 52.49 | 59.55 | 88.16 | 1024 |
| 7 | 52.60 | 65.86 | 85.61 | 1024 |
| 8 | 76.04 | 82.89 | 115.15 | 1024 |
| 9 | 85.61 | 92.73 | 126.43 | 1024 |
| 10 | 88.16 | 99.07 | 135.44 | 1024 |
| 11 | 102.75 | 109.64 | 165.43 | 1024 |
| 12 | 115.15 | 122.05 | 150.62 | 1024 |
| 13 | 126.44 | 133.30 | 170.43 | 1024 |
| 14 | 135.44 | 142.32 | 162.97 | 1024 |
| 15 | 150.63 | 157.52 | 170.22 | 1024 |

</details>

<details><summary>16k/1k c=4, B2 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 6.85 | 51.91 | 1024 |
| 1 | 0.00 | 18.90 | 38.60 | 1024 |
| 2 | 0.00 | 12.45 | 56.96 | 1024 |
| 3 | 0.00 | 25.13 | 39.10 | 1024 |
| 4 | 38.60 | 45.65 | 78.14 | 1024 |
| 5 | 39.10 | 51.91 | 93.13 | 1024 |
| 6 | 51.91 | 59.02 | 85.44 | 1024 |
| 7 | 56.96 | 65.33 | 100.00 | 1024 |
| 8 | 78.14 | 84.99 | 116.67 | 1024 |
| 9 | 85.44 | 92.28 | 131.34 | 1024 |
| 10 | 93.13 | 99.99 | 126.65 | 1024 |
| 11 | 100.00 | 106.86 | 131.76 | 1024 |
| 12 | 116.67 | 123.53 | 155.04 | 1024 |
| 13 | 126.65 | 133.84 | 160.24 | 1024 |
| 14 | 131.34 | 140.44 | 160.18 | 1024 |
| 15 | 131.76 | 146.80 | 159.71 | 1024 |

</details>

<details><summary>16k/1k c=4, A2 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 6.87 | 37.36 | 1024 |
| 1 | 0.00 | 12.49 | 57.91 | 1024 |
| 2 | 0.00 | 18.93 | 37.84 | 1024 |
| 3 | 0.00 | 25.16 | 46.43 | 1024 |
| 4 | 37.36 | 44.41 | 76.56 | 1024 |
| 5 | 37.84 | 50.96 | 92.14 | 1024 |
| 6 | 46.43 | 57.26 | 83.47 | 1024 |
| 7 | 57.91 | 64.77 | 118.55 | 1024 |
| 8 | 76.56 | 83.41 | 109.17 | 1024 |
| 9 | 83.47 | 90.31 | 128.07 | 1024 |
| 10 | 92.14 | 99.00 | 134.85 | 1024 |
| 11 | 109.17 | 116.02 | 150.53 | 1024 |
| 12 | 118.55 | 125.45 | 159.51 | 1024 |
| 13 | 128.07 | 134.93 | 171.67 | 1024 |
| 14 | 134.85 | 141.74 | 161.72 | 1024 |
| 15 | 150.53 | 157.41 | 168.95 | 1024 |

</details>

<details><summary>16k/1k c=8, A1 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 6.98 | 92.72 | 1024 |
| 1 | 0.00 | 12.68 | 80.93 | 1024 |
| 2 | 0.00 | 32.52 | 101.97 | 1024 |
| 3 | 0.00 | 19.23 | 66.12 | 1024 |
| 4 | 0.00 | 25.88 | 70.86 | 1024 |
| 5 | 0.00 | 39.21 | 79.96 | 1024 |
| 6 | 0.01 | 45.91 | 108.00 | 1024 |
| 7 | 0.01 | 52.33 | 134.16 | 1024 |
| 8 | 66.12 | 73.42 | 126.81 | 1024 |
| 9 | 70.86 | 79.83 | 147.45 | 1024 |
| 10 | 79.96 | 87.26 | 141.42 | 1024 |
| 11 | 80.94 | 94.01 | 163.29 | 1024 |
| 12 | 92.73 | 100.44 | 156.85 | 1024 |
| 13 | 101.98 | 109.29 | 162.01 | 1024 |
| 14 | 108.00 | 115.73 | 178.94 | 1024 |
| 15 | 126.81 | 133.79 | 208.73 | 1024 |
| 16 | 134.16 | 141.14 | 194.92 | 1024 |
| 17 | 141.42 | 148.74 | 235.48 | 1024 |
| 18 | 147.45 | 155.16 | 198.81 | 1024 |
| 19 | 156.85 | 164.16 | 244.15 | 1024 |
| 20 | 162.01 | 170.90 | 227.21 | 1024 |
| 21 | 163.29 | 177.34 | 260.43 | 1024 |
| 22 | 178.94 | 185.91 | 221.60 | 1024 |
| 23 | 194.92 | 202.23 | 256.53 | 1024 |
| 24 | 198.81 | 208.66 | 278.46 | 1024 |
| 25 | 208.73 | 215.70 | 278.55 | 1024 |
| 26 | 221.60 | 228.93 | 275.34 | 1024 |
| 27 | 227.21 | 235.35 | 277.62 | 1024 |
| 28 | 235.48 | 242.44 | 278.85 | 1024 |
| 29 | 244.15 | 251.17 | 280.85 | 1024 |
| 30 | 256.53 | 263.84 | 284.21 | 1024 |
| 31 | 260.43 | 270.27 | 290.49 | 1024 |

</details>

<details><summary>16k/1k c=8, B1 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 7.00 | 65.29 | 1024 |
| 1 | 0.00 | 12.70 | 80.01 | 1024 |
| 2 | 0.00 | 19.22 | 72.35 | 1024 |
| 3 | 0.00 | 25.87 | 113.84 | 1024 |
| 4 | 0.00 | 32.53 | 80.05 | 1024 |
| 5 | 0.00 | 45.94 | 101.66 | 1024 |
| 6 | 0.01 | 52.33 | 86.46 | 1024 |
| 7 | 0.01 | 39.25 | 133.73 | 1024 |
| 8 | 65.29 | 72.27 | 124.74 | 1024 |
| 9 | 72.35 | 79.32 | 133.69 | 1024 |
| 10 | 80.01 | 87.33 | 176.32 | 1024 |
| 11 | 80.05 | 94.07 | 149.72 | 1024 |
| 12 | 86.46 | 100.49 | 156.70 | 1024 |
| 13 | 101.66 | 108.64 | 199.59 | 1024 |
| 14 | 113.84 | 120.82 | 169.35 | 1024 |
| 15 | 124.74 | 131.72 | 184.40 | 1024 |
| 16 | 133.69 | 140.95 | 210.64 | 1024 |
| 17 | 133.73 | 147.36 | 195.71 | 1024 |
| 18 | 149.72 | 156.68 | 254.10 | 1024 |
| 19 | 156.70 | 163.67 | 218.62 | 1024 |
| 20 | 169.35 | 176.32 | 232.66 | 1024 |
| 21 | 176.32 | 183.33 | 287.82 | 1024 |
| 22 | 184.40 | 191.38 | 236.55 | 1024 |
| 23 | 195.71 | 203.01 | 273.36 | 1024 |
| 24 | 199.59 | 209.42 | 276.88 | 1024 |
| 25 | 210.64 | 217.61 | 286.24 | 1024 |
| 26 | 218.62 | 225.60 | 263.09 | 1024 |
| 27 | 232.66 | 239.96 | 282.23 | 1024 |
| 28 | 236.55 | 246.37 | 283.11 | 1024 |
| 29 | 254.10 | 261.10 | 291.21 | 1024 |
| 30 | 263.09 | 270.07 | 293.32 | 1024 |
| 31 | 273.37 | 280.36 | 306.93 | 1024 |

</details>

<details><summary>16k/1k c=8, B2 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 6.99 | 97.34 | 1024 |
| 1 | 0.00 | 12.69 | 91.84 | 1024 |
| 2 | 0.00 | 19.21 | 117.11 | 1024 |
| 3 | 0.00 | 25.87 | 75.61 | 1024 |
| 4 | 0.00 | 32.52 | 67.09 | 1024 |
| 5 | 0.00 | 39.21 | 70.13 | 1024 |
| 6 | 0.01 | 52.30 | 87.53 | 1024 |
| 7 | 0.01 | 45.92 | 126.65 | 1024 |
| 8 | 67.09 | 74.37 | 134.88 | 1024 |
| 9 | 70.13 | 81.11 | 143.06 | 1024 |
| 10 | 75.61 | 87.51 | 150.55 | 1024 |
| 11 | 87.53 | 94.83 | 157.78 | 1024 |
| 12 | 91.84 | 101.58 | 171.83 | 1024 |
| 13 | 97.34 | 108.00 | 197.23 | 1024 |
| 14 | 117.11 | 124.06 | 179.50 | 1024 |
| 15 | 126.65 | 133.61 | 189.54 | 1024 |
| 16 | 134.88 | 141.86 | 189.59 | 1024 |
| 17 | 143.06 | 150.02 | 213.67 | 1024 |
| 18 | 150.55 | 157.51 | 206.93 | 1024 |
| 19 | 157.78 | 164.77 | 226.98 | 1024 |
| 20 | 171.83 | 178.79 | 240.44 | 1024 |
| 21 | 179.50 | 186.48 | 288.61 | 1024 |
| 22 | 189.55 | 196.84 | 249.98 | 1024 |
| 23 | 189.59 | 203.58 | 258.94 | 1024 |
| 24 | 197.23 | 210.33 | 259.08 | 1024 |
| 25 | 206.93 | 217.09 | 289.78 | 1024 |
| 26 | 213.67 | 223.53 | 273.11 | 1024 |
| 27 | 226.98 | 233.98 | 276.87 | 1024 |
| 28 | 240.44 | 247.41 | 282.19 | 1024 |
| 29 | 249.98 | 256.99 | 287.51 | 1024 |
| 30 | 258.94 | 266.24 | 287.47 | 1024 |
| 31 | 259.08 | 272.66 | 289.61 | 1024 |

</details>

<details><summary>16k/1k c=8, A2 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 6.98 | 70.95 | 1024 |
| 1 | 0.00 | 12.69 | 77.71 | 1024 |
| 2 | 0.00 | 19.22 | 64.92 | 1024 |
| 3 | 0.00 | 25.88 | 73.06 | 1024 |
| 4 | 0.00 | 32.55 | 79.82 | 1024 |
| 5 | 0.00 | 39.26 | 121.11 | 1024 |
| 6 | 0.01 | 45.96 | 99.87 | 1024 |
| 7 | 0.01 | 52.37 | 107.04 | 1024 |
| 8 | 64.92 | 72.24 | 133.92 | 1024 |
| 9 | 70.95 | 79.01 | 151.94 | 1024 |
| 10 | 73.06 | 85.77 | 164.77 | 1024 |
| 11 | 77.71 | 92.52 | 133.93 | 1024 |
| 12 | 79.82 | 98.96 | 148.47 | 1024 |
| 13 | 99.87 | 106.87 | 193.21 | 1024 |
| 14 | 107.04 | 114.04 | 178.20 | 1024 |
| 15 | 121.11 | 128.11 | 181.67 | 1024 |
| 16 | 133.92 | 141.22 | 225.39 | 1024 |
| 17 | 133.93 | 147.65 | 218.90 | 1024 |
| 18 | 148.47 | 155.77 | 201.73 | 1024 |
| 19 | 151.94 | 162.19 | 210.52 | 1024 |
| 20 | 164.77 | 171.72 | 239.63 | 1024 |
| 21 | 178.20 | 185.52 | 247.15 | 1024 |
| 22 | 181.67 | 191.94 | 275.72 | 1024 |
| 23 | 193.21 | 200.22 | 256.65 | 1024 |
| 24 | 201.73 | 208.73 | 278.30 | 1024 |
| 25 | 210.52 | 217.54 | 282.40 | 1024 |
| 26 | 218.90 | 225.91 | 275.32 | 1024 |
| 27 | 225.39 | 232.76 | 267.49 | 1024 |
| 28 | 239.63 | 246.61 | 294.18 | 1024 |
| 29 | 247.15 | 254.15 | 284.19 | 1024 |
| 30 | 256.65 | 263.64 | 287.71 | 1024 |
| 31 | 267.49 | 274.47 | 289.59 | 1024 |

</details>

<details><summary>32k/2k c=4, A1 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 13.15 | 77.55 | 2048 |
| 1 | 0.00 | 25.68 | 76.57 | 2048 |
| 2 | 0.00 | 52.36 | 117.75 | 2048 |
| 3 | 0.00 | 39.11 | 96.13 | 2048 |
| 4 | 76.57 | 90.70 | 180.32 | 2048 |
| 5 | 77.55 | 104.25 | 164.48 | 2048 |
| 6 | 96.13 | 117.57 | 155.82 | 2048 |
| 7 | 117.75 | 131.74 | 201.68 | 2048 |
| 8 | 155.82 | 170.09 | 234.30 | 2048 |
| 9 | 164.48 | 183.80 | 248.90 | 2048 |
| 10 | 180.32 | 197.14 | 289.94 | 2048 |
| 11 | 201.68 | 215.64 | 275.69 | 2048 |
| 12 | 234.30 | 248.23 | 312.95 | 2048 |
| 13 | 248.90 | 262.88 | 314.56 | 2048 |
| 14 | 275.69 | 289.71 | 329.06 | 2048 |
| 15 | 289.94 | 303.94 | 327.11 | 2048 |

</details>

<details><summary>32k/2k c=4, B1 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 13.11 | 76.66 | 2048 |
| 1 | 0.00 | 52.28 | 122.63 | 2048 |
| 2 | 0.00 | 39.01 | 104.26 | 2048 |
| 3 | 0.00 | 25.62 | 87.47 | 2048 |
| 4 | 76.66 | 90.93 | 156.22 | 2048 |
| 5 | 87.47 | 104.26 | 171.73 | 2048 |
| 6 | 104.26 | 118.23 | 167.04 | 2048 |
| 7 | 122.63 | 136.60 | 218.20 | 2048 |
| 8 | 156.22 | 170.51 | 234.63 | 2048 |
| 9 | 167.04 | 184.10 | 258.72 | 2048 |
| 10 | 171.73 | 197.44 | 283.81 | 2048 |
| 11 | 218.20 | 232.17 | 283.96 | 2048 |
| 12 | 234.63 | 248.59 | 313.34 | 2048 |
| 13 | 258.72 | 272.68 | 342.42 | 2048 |
| 14 | 283.81 | 297.97 | 338.25 | 2048 |
| 15 | 283.96 | 311.36 | 337.62 | 2048 |

</details>

<details><summary>32k/2k c=4, B2 head: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 13.15 | 118.43 | 2048 |
| 1 | 0.00 | 25.68 | 97.98 | 2048 |
| 2 | 0.00 | 39.06 | 78.75 | 2048 |
| 3 | 0.00 | 52.34 | 86.53 | 2048 |
| 4 | 78.75 | 92.98 | 158.03 | 2048 |
| 5 | 86.53 | 106.53 | 215.92 | 2048 |
| 6 | 97.99 | 120.18 | 172.44 | 2048 |
| 7 | 118.43 | 133.53 | 187.88 | 2048 |
| 8 | 158.03 | 172.02 | 236.60 | 2048 |
| 9 | 172.44 | 186.46 | 252.31 | 2048 |
| 10 | 187.88 | 201.89 | 282.36 | 2048 |
| 11 | 215.92 | 229.91 | 295.40 | 2048 |
| 12 | 236.60 | 250.57 | 319.57 | 2048 |
| 13 | 252.31 | 266.29 | 319.93 | 2048 |
| 14 | 282.36 | 296.72 | 334.04 | 2048 |
| 15 | 295.40 | 310.11 | 334.21 | 2048 |

</details>

<details><summary>32k/2k c=4, A2 base: submit, first token and last token of each request</summary>

| request | submit (s) | first token (s) | last token (s) | output tokens |
|---|---|---|---|---|
| 0 | 0.00 | 13.14 | 77.01 | 2048 |
| 1 | 0.00 | 25.68 | 93.02 | 2048 |
| 2 | 0.00 | 52.38 | 129.33 | 2048 |
| 3 | 0.00 | 39.11 | 91.17 | 2048 |
| 4 | 77.01 | 90.97 | 157.35 | 2048 |
| 5 | 91.17 | 105.31 | 253.13 | 2048 |
| 6 | 93.02 | 118.63 | 164.72 | 2048 |
| 7 | 129.33 | 143.33 | 195.88 | 2048 |
| 8 | 157.35 | 171.61 | 224.86 | 2048 |
| 9 | 164.72 | 185.01 | 232.22 | 2048 |
| 10 | 195.88 | 209.89 | 275.09 | 2048 |
| 11 | 224.86 | 239.11 | 304.03 | 2048 |
| 12 | 232.22 | 252.49 | 331.41 | 2048 |
| 13 | 253.13 | 267.16 | 343.95 | 2048 |
| 14 | 275.09 | 289.09 | 330.71 | 2048 |
| 15 | 304.03 | 318.05 | 343.20 | 2048 |

</details>

#### Stall probe

`stall_probe.py` on every speed boot (`inject` and `reverse`, with `solo` for the reference TTFT; `--server-pid`, so a KFD eviction invalidates a window). Hard gate: no decoder stream is starved, and every decoder produces tokens during every injected prefill; `reverse` windows are reported but are not part of it. Relative metrics, reported for the reviewer and never failing the run: the longest stall, the stalled time, the decode tokens during the prefill, Jain fairness and the injected request's TTFT against its solo TTFT, each with the ABBA verdict of the speed table.

| boot | role | decoders | repeats | prefill tokens | injected prefills measured | most decoders starved in a window | fewest tokens of a decoder in a window | windows hit by a KFD eviction | hard gate |
|---|---|---|---|---|---|---|---|---|---|
| A1 | base | 7 | 3 | 4096/16384 | 6 | 0 | 7 | 0 | PASS |
| B1 | head | 7 | 3 | 4096/16384 | 6 | 0 | 7 | 0 | PASS |
| B2 | head | 7 | 3 | 4096/16384 | 6 | 0 | 12 | 0 | PASS |
| A2 | base | 7 | 3 | 4096/16384 | 6 | 0 | 9 | 0 | PASS |

| window | metric | A1 base | B1 head | B2 head | A2 base | head vs base | result |
|---|---|---|---|---|---|---|---|
| inject:4096 | longest stall (ms) | 420 | 420 | 420 | 420 | -0.0 % | no measurable difference |
| inject:4096 | stalled time of the worst decoder (s) | 1.62 | 1.62 | 1.63 | 1.63 | +0.1 % | no measurable difference |
| inject:4096 | decode tokens during the prefill | 107 | 102 | 108 | 104 | -0.5 % | no measurable difference |
| inject:4096 | Jain fairness | 0.947 | 0.975 | 0.974 | 0.956 | +2.5 % | better |
| inject:4096 | injected TTFT / solo TTFT (x) | 1.20 | 1.21 | 1.20 | 1.21 | -0.2 % | no measurable difference |
| inject:16384 | longest stall (ms) | 432 | 433 | 433 | 433 | -0.0 % | no measurable difference |
| inject:16384 | stalled time of the worst decoder (s) | 6.67 | 6.68 | 6.69 | 6.69 | +0.1 % | no measurable difference |
| inject:16384 | decode tokens during the prefill | 291 | 310 | 291 | 322 | -2.0 % | no measurable difference |
| inject:16384 | Jain fairness | 0.982 | 0.991 | 0.984 | 0.975 | +0.9 % | better |
| inject:16384 | injected TTFT / solo TTFT (x) | 1.17 | 1.17 | 1.17 | 1.17 | +0.0 % | no measurable difference |
| reverse:16384 | longest stall (ms) | 5203 | 5207 | 5203 | 5209 | -0.0 % | no measurable difference |
| reverse:16384 | stalled time of the worst decoder (s) | 5.20 | 5.21 | 5.20 | 5.21 | -0.0 % | no measurable difference |
| reverse:16384 | decode tokens during the prefill | 13 | 9 | 18 | 11 | +12.5 % | no measurable difference |
| reverse:16384 | Jain fairness | 0.784 | 0.890 | 0.857 | 0.691 | +18.4 % | better |
| reverse:16384 | injected TTFT / solo TTFT (x) | 1.08 | 1.08 | 1.07 | 1.08 | +0.0 % | no measurable difference |

`inject:<n>`: a prefill of n tokens injected into the running decoders, from its submit to its first token. `reverse:<n>`: the n-token prefill is already running when the decoders arrive. Each value is the median over the repeats of one boot. `worse` and `better` apply the ABBA rule: both head runs on the same side of both base runs; anything else is no measurable difference. They are for the reviewer and never fail the run.

#### Added host syncs and launches

Lines the change adds that match a host-synchronization pattern (`synchronize(`, `.item()`, `.cpu()`, `.tolist()`, a blocking copy) in `vllm/`, or a kernel launch on the null stream or without a launch check in `csrc/`. The scan lists them for the reviewer, who decides whether one is on the per-step path and whether the PR measures why it is needed; it gives no verdict.

5 added lines to review (4 in the per-step path): cpu x 4, tolist x 1 (8 vllm/ and 3 csrc/ files changed).

| where | pattern | code |
| --- | --- | --- |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:232` | cpu | `self.slot = expert_map.detach().cpu().numpy().astype(np.int32)` |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:480` | cpu | `result = out.cpu().numpy()` |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:628` | cpu | `result = out.cpu().numpy()` |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:636` | tolist | `self._disable(f"swap vote failed: {result.tolist()}")` |
| `vllm/models/qwen4_exp/amd/mono/rdna2/layout.py:439` | cpu | `emap[loc].sort().values.cpu(),` |

### Boots

| boot | role | kind | READY | summary | probes | KFD evictions since READY | max GPU temp | fault markers | dmesg faults | exit |
|---|---|---|---|---|---|---|---|---|---|---|
| XA | base | exact | 311 s | complete | all 5 pass | ok | 67 C | 0 | 0 | 0 |
| XB | head | exact | 311 s | complete | all 5 pass | ok | 70 C | 0 | 0 | 0 |
| A1 | base | speed | 301 s | complete | all 5 pass | ok | 84 C | 0 | 0 | 0 |
| B1 | head | speed | 301 s | complete | all 5 pass | ok | 84 C | 0 | 0 | 0 |
| B2 | head | speed | 301 s | complete | all 5 pass | ok | 84 C | 0 | 0 | 0 |
| A2 | base | speed | 311 s | complete | all 5 pass | ok | 83 C | 0 | 0 | 0 |

### Raw results

- Run directory: `/home/chenco_adm/w4a8_runs/eplb-online/final-2ea7a364848c/campaign-01/r1` on par1-cs25; per boot directory (`boots/<id>/`): `serve.log`, `summary.txt`, `bench-*.json`, `concurrency.json`, `topk.npz`, `quality.json`.
- Command: `BASE_TREE=/home/chenco_adm/w4a8_runs/leapquant/tree-eplb-base HEAD_TREE=/home/chenco_adm/w4a8_runs/leapquant/tree-eplb-final-2ea7a364848c BASE_VENV=/home/chenco_adm/Apps/vllm/venv-7.14.0_0.32.0 HEAD_VENV=/home/chenco_adm/Apps/vllm/venv-7.14.0_0.32.0 RECIPE=flashnext-mtp2 MODEL=/home/chenco_adm/.cache/huggingface/hub/models--wtdcode--Qwen3.8-Flash-Next-AWQ-W4A16/snapshots/0939125b929543a783ce700c90e36dd1a575c00c GPUS=2,3,4,5 MODE=abba EXACT=1 QUALITY=0 STALL=1 STALL_REPEATS=3 STALL_LENS=4096,16384 STALL_DECODERS=7 CELLS='1024:512:1 1024:512:4 1024:512:8 16384:1024:1 16384:1024:4 16384:1024:8 32768:2048:1 32768:2048:4' EXACT_CELLS='1024:128:1:4 16384:128:1:2' bash tools/rdna/pr_receipt.sh`
