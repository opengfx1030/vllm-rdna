5 added lines to review (4 in the per-step path): cpu x 4, tolist x 1 (8 vllm/ and 3 csrc/ files changed).

| where | pattern | code |
| --- | --- | --- |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:232` | cpu | `self.slot = expert_map.detach().cpu().numpy().astype(np.int32)` |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:480` | cpu | `result = out.cpu().numpy()` |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:628` | cpu | `result = out.cpu().numpy()` |
| `vllm/model_executor/layers/fused_moe/rdna_eplb_online.py:636` | tolist | `self._disable(f"swap vote failed: {result.tolist()}")` |
| `vllm/models/qwen4_exp/amd/mono/rdna2/layout.py:439` | cpu | `emap[loc].sort().values.cpu(),` |
