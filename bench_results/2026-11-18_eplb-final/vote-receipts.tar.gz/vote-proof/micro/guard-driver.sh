#!/usr/bin/env bash
set -euo pipefail
TREE=$HOME/w4a8_runs/leapquant/tree-eplb-vote-6195fb0b465a
OLD=$HOME/w4a8_runs/leapquant/tree-eplb-counter-20aedaa1cde2
RUN=$HOME/w4a8_runs/eplb-online/vote-6195fb0b465a/micro
OWNER=EplbVoteMicro6195
LEASE=b4
export OWNER LEASE HIP_VISIBLE_DEVICES=
unset ROCR_VISIBLE_DEVICES CUDA_VISIBLE_DEVICES
VENV=$HOME/Apps/vllm/venv-7.14.0_0.32.0
SITE=$VENV/lib/python3.12/site-packages
export LD_LIBRARY_PATH=$SITE/_rocm_sdk_libraries/lib:$SITE/_rocm_sdk_core/lib/host-math/lib:$SITE/_rocm_sdk_core/lib/rocm_sysdeps/lib:$SITE/_rocm_sdk_core/lib:$SITE/torch/lib
[[ ! -e $RUN ]] || { echo "Refusing to overwrite $RUN"; exit 2; }
[[ ! -e $HOME/w4a8_runs/lanes/lease/b4.request ]] || { echo 'Another request is queued'; exit 2; }
source "$HOME/w4a8_runs/leapquant/lease.sh"
QUIET=$HOME/w4a8_runs/lanes/quiet-b4/$OWNER
tw= child=
cleanup() {
    local rc=$?
    trap - EXIT
    [[ -z $child ]] || kill -- "-$child" 2>/dev/null || true
    [[ -z $tw ]] || kill "$tw" 2>/dev/null || true
    rm -f "$L/$OWNER.$LEASE" "$QUIET"
    if [[ -f $L/$LEASE.request ]] && grep -q "^$OWNER " "$L/$LEASE.request"; then
        rm -f "$L/$LEASE.request"
    fi
    [[ ! -d $RUN ]] || printf '%s\n' "$rc" > "$RUN/exit-code"
    exit "$rc"
}
trap cleanup EXIT
trap 'exit 143' TERM INT
lease_take 'bounded EPLB actual-method per-site micro; no model qualification' 10
mkdir -p "$RUN" "$(dirname "$QUIET")"
touch "$QUIET"
exec 8> "$HOME/w4a8_runs/audit/build.lock"
flock -s -w 120 8
exec 9> "$HOME/w4a8_runs/boot.lock"
flock -w 120 9
! pgrep -f '^/usr/sbin/docker buildx build' >/dev/null || { echo 'Image build active'; exit 3; }
GUARD=$TREE/tools/rdna/eplb/qualify_boot.py
cpu() { env -u ROCR_VISIBLE_DEVICES -u CUDA_VISIBLE_DEVICES HIP_VISIBLE_DEVICES= /usr/bin/python3 "$@"; }
buses=$(cpu "$GUARD" gpus --venv "$VENV" --out "$RUN/gpus.json")
[[ $buses == 'd9 dc df e2' ]]
cpu "$GUARD" aer --buses "$buses" --out "$RUN/aer-before.json"
cpu "$TREE/tools/rdna/tp8pp2/tempwatch.py" d9,dc,df,e2 "$RUN/temps.log" "$RUN/temps-all.log" "$RUN/gpu.pid" "$RUN/THERMAL_ABORT" > "$RUN/tempwatch.log" 2>&1 &
tw=$!
sleep 2
kill -0 "$tw"
[[ ! -e $RUN/THERMAL_ABORT ]]
cp "$TREE/.proof/vote_proof.py" "$RUN/proof-driver.py"
cp "$TREE/.proof/vote_micro.sh" "$RUN/guard-driver.sh"
sha256sum "$RUN/proof-driver.py" "$RUN/guard-driver.sh" > "$RUN/drivers.sha256"
setsid env -u ROCR_VISIBLE_DEVICES -u CUDA_VISIBLE_DEVICES HIP_VISIBLE_DEVICES=2,3,4,5 PYTHONPATH="$TREE" HSA_ENABLE_SDMA=0 GPU_MAX_HW_QUEUES=2 OMP_NUM_THREADS=1 VLLM_RDNA_EPLB=0 VLLM_RDNA_EPLB_STATS_DIR= VLLM_ROCM_USE_AITER=0 VLLM_ROCM_USE_AITER_MOE=0 TORCH_BLAS_PREFER_HIPBLASLT=0 PYTORCH_TUNABLEOP_ENABLED=0 PYTORCH_TUNABLEOP_HIPBLASLT_ENABLED=0 VLLM_BATCH_INVARIANT=0 timeout 180 "$VENV/bin/python" "$TREE/.proof/vote_proof.py" micro --new-tree "$TREE" --old-tree "$OLD" --out "$RUN" --iterations 100 > "$RUN/proof.log" 2>&1 &
child=$!
printf '%s\n' "$child" > "$RUN/gpu.pid"
wait "$child"
child=
kill -0 "$tw"
[[ ! -e $RUN/THERMAL_ABORT ]]
cpu "$GUARD" aer --buses "$buses" --out "$RUN/aer-after.json"
cpu "$GUARD" aer-compare "$RUN/aer-before.json" "$RUN/aer-after.json"
cpu "$GUARD" temps --log "$RUN/temps.log" --buses "$buses" --abort "$RUN/THERMAL_ABORT"
cpu "$GUARD" faults --log "$RUN/proof.log"
! pgrep -f '^/usr/sbin/docker buildx build' >/dev/null || { echo 'Image build appeared'; exit 3; }
cat "$RUN/result.json"
