#!/usr/bin/env python3
"""Throwaway proof driver; caller owns b4 lease, quiet/thermal/AER guards.

Runs actual controller methods, not a replacement implementation. Micro results
are synthetic per-site costs, NOT model ITL or an EPLB qualification.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def controller(module, words, source):
    ctl = module.OnlineEplb(module.OnlineConfig())
    dev = source.device
    ctl._vote = torch.zeros(module.VOTE_WORDS, dtype=torch.int32, device=dev)
    coefficients = torch.arange(words, dtype=torch.int64, device=dev)
    coefficients.remainder_(module.CHECK_MOD).add_(1)
    if hasattr(ctl, '_checksum_into'):
        ctl._check = coefficients.to(torch.int32)
        ctl._products = torch.empty(words, dtype=torch.int32, device=dev)
        ctl._checksum_sum = torch.empty((), dtype=torch.int32, device=dev)
        ctl._vote_host = torch.empty(module.VOTE_WORDS, dtype=torch.int32, pin_memory=True)
        ctl._pair = torch.empty(2, dtype=torch.int64, device=dev)
        ctl._pair_host = torch.empty(2, dtype=torch.int64)
        ctl._slots = torch.empty(2, dtype=torch.int32, device=dev)
        ctl._slots_host = torch.empty(2, dtype=torch.int32)
        ctl._owners = torch.empty(2, dtype=torch.uint8, device=dev)
        ctl._owners_host = torch.empty(2, dtype=torch.uint8)
    else:
        ctl._check = coefficients
    ctl._recv = source.clone()
    ctl._slot = 0
    widths = [words // 6 + int(i < words % 6) for i in range(6)]
    views = [torch.empty((1, n), dtype=torch.int32, device=dev) for n in widths]
    ctl.layers = [SimpleNamespace(
        views=views, widths=widths,
        expert_map=torch.tensor([0, -1], dtype=torch.int32, device=dev),
        slot=np.array([0, -1], dtype=np.int32),
        owner=np.array([0, 1], dtype=np.uint8),
        stats=SimpleNamespace(owner=torch.tensor([0, 1], dtype=torch.uint8, device=dev)),
    )]
    return ctl


def sample(fn, iterations):
    for _ in range(20):
        fn()
    torch.cuda.synchronize()
    start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    start.record(); end.record(); end.synchronize()
    allocations = torch.cuda.memory_stats()['allocation.all.allocated']
    host, stream = [], []
    for _ in range(iterations):
        start.record()
        before = time.perf_counter_ns()
        fn()
        end.record()
        end.synchronize()
        host.append((time.perf_counter_ns() - before) / 1000)
        stream.append(start.elapsed_time(end) * 1000)
    allocation_delta = torch.cuda.memory_stats()['allocation.all.allocated'] - allocations
    return {
        'samples': iterations,
        'wall_sync_us_p50': float(np.median(host)),
        'wall_sync_us_p95': float(np.percentile(host, 95)),
        'stream_elapsed_us_p50': float(np.median(stream)),
        'torch_allocator_calls': allocation_delta,
        'allocator_calls_per_sample': allocation_delta / iterations,
    }


def micro(old, new, iterations):
    records = []
    torch.manual_seed(17)
    for words in (12288, 638400):
        source = torch.randint(-(2**31), 2**31-1, (words,), dtype=torch.int32, device='cuda')
        ctls = {'old': controller(old, words, source), 'new': controller(new, words, source)}
        swap = new.Swap(0, 0, 1, 0, 1, words)
        expected = (source.cpu().to(torch.int64) * ctls['old']._check.cpu()).sum().item() & old.CHECK_MASK
        for label, ctl in ctls.items():
            if label == 'old':
                def hash_pair(c=ctl):
                    c._vote.zero_()
                    c._vote[old.V_SENT_A:old.V_SENT_A+1].copy_(c._checksum(source, words))
                    c._vote[old.V_GOT_B:old.V_GOT_B+1].copy_(c._checksum(source, words))
            else:
                def hash_pair(c=ctl):
                    c._vote.zero_()
                    c._checksum_into(source, words, c._vote[new.V_SENT_A:new.V_SENT_A+1])
                    c._checksum_into(source, words, c._vote[new.V_GOT_B:new.V_GOT_B+1])
            hash_pair()
            assert ctl._vote[old.V_SENT_A].item() == expected
            assert ctl._vote[old.V_GOT_B].item() == expected
            ctl._hash_pair = hash_pair
        for site in ('checksum_pair', 'commit', 'vote_d2h'):
            for arm, label in enumerate(('old', 'new', 'new', 'old')):
                ctl = ctls[label]
                if site == 'checksum_pair':
                    fn = ctl._hash_pair
                elif site == 'commit':
                    fn = lambda c=ctl: c._commit(swap)
                elif label == 'old':
                    fn = lambda c=ctl: c._vote.cpu().numpy()
                else:
                    def fn(c=ctl):
                        c._vote_host.copy_(c._vote)
                        return c._vote_host.numpy()
                records.append({'words': words, 'site': site, 'arm': arm,
                                'version': label, **sample(fn, iterations)})
        for ctl in ctls.values():
            layer = ctl.layers[0]
            assert layer.expert_map.cpu().tolist() == [-1, 0]
            assert layer.stats.owner.cpu().tolist() == [1, 0]
            assert torch.equal(torch.cat([v.flatten() for v in layer.views]), source)
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('gpu-tests', 'micro'))
    parser.add_argument('--new-tree', type=Path, required=True)
    parser.add_argument('--old-tree', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--iterations', type=int, default=100)
    args = parser.parse_args()
    assert os.environ.get('HIP_VISIBLE_DEVICES') == '2,3,4,5'
    assert os.environ.get('VLLM_RDNA_EPLB', '0') == '0'
    assert not os.environ.get('VLLM_RDNA_EPLB_STATS_DIR')
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out/'gpu.pid').write_text(str(os.getpid())+'\n')
    import vllm
    assert Path(vllm.__file__).resolve().parent.parent == args.new_tree.resolve()
    props = torch.cuda.get_device_properties(0)
    assert 'V620' in props.name and props.gcnArchName.startswith('gfx1030')
    torch.set_num_threads(1)
    torch.zeros(1, device='cuda')
    torch.cuda.synchronize()
    kfd = load(args.new_tree/'tools/rdna/port_v031/kfd_evictions.py', 'vote_proof_kfd')
    before = kfd.evicted_ms(os.getpid())
    assert before is not None, 'KFD eviction state unknown'
    result = {'mode': args.mode, 'torch': torch.__version__, 'hip': torch.version.hip,
              'device': props.name, 'arch': props.gcnArchName,
              'new_sha': (args.new_tree/'.sha').read_text().strip(),
              'note': 'Synthetic method microbench only; not model latency or qualification.'}
    rc = 0
    if args.mode == 'gpu-tests':
        import pytest
        rc = pytest.main(['--noconftest', '-p', 'no:cacheprovider',
            str(args.new_tree/'tests/model_executor/layers/fused_moe/test_rdna_eplb_online.py'),
            '-k', 'swapped or mailbox_error or (vote_checksum and cuda)', '-q'])
        result['pytest_rc'] = rc
    else:
        assert args.old_tree is not None
        from vllm.model_executor.layers.fused_moe import rdna_eplb_online as new
        old = load(args.old_tree/'vllm/model_executor/layers/fused_moe/rdna_eplb_online.py', 'vote_proof_old')
        result['old_sha'] = (args.old_tree/'.sha').read_text().strip()
        result['records'] = micro(old, new, args.iterations)
    after = kfd.evicted_ms(os.getpid())
    result.update(kfd_before=before, kfd_after=after, kfd_valid=after == before)
    (args.out/'result.json').write_text(json.dumps(result, indent=2)+'\n')
    assert after == before, 'KFD eviction invalidates this window'
    raise SystemExit(rc)


if __name__ == '__main__':
    main()
