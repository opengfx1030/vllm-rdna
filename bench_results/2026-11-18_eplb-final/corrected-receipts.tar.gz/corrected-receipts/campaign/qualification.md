# EPLB final qualification: r2

result: not qualified
design: A1 off, B1 chaos, B2 chaos, A2 off; `--monokernel`; cells 1024:512:1 1024:512:8 16384:1024:1 16384:1024:8

| arm | EPLB | mono | K2 3-row FULL | modules >=24 | plan cells | unfinished | faults | ok |
|---|---|---|---|---|---|---|---|---|
| A1 | off | 4 | 4 | 4 | 0 | 0 | 0 | yes |
| B1 | on | 4 | 4 | 4 | 4 | 1 | 0 | yes |
| B2 | on | 4 | 4 | 4 | 4 | 1 | 0 | yes |
| A2 | off | 4 | 4 | 4 | 0 | 0 | 0 | yes |

K2 evidence is the c=1/probe 3-row FULL path; the c=8 module path is the >=24-row evidence. They are never merged.

Injection coverage was not run (STALL_PROBE=0). The old paired injection gate is historical and exercised the modules path only (>=21 rows); no mapped K2 under injection is claimed here.

Problems:
- 1024x512-c1 median_itl_ms: verdict 'FAIL', not pass
- 1024x512-c1 p99_itl_ms: verdict 'FAIL', not pass
- 1024x512-c8 median_itl_ms: verdict 'FAIL', not pass
- 1024x512-c8 p99_itl_ms: verdict 'FAIL', not pass
- 16384x1024-c1 median_itl_ms: verdict 'FAIL', not pass
- 16384x1024-c1 p99_itl_ms: verdict 'FAIL', not pass
- 16384x1024-c8 median_itl_ms: verdict 'FAIL', not pass
