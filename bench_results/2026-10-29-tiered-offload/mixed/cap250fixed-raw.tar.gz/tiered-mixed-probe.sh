#!/usr/bin/env bash
set -euo pipefail
TREE=/home/chenco_adm/opengfx1030_vllm-rdna_moe_offloading
ROOT=/home/chenco_adm/w4a8_runs/moe-offload/tiered-first-pass
: "${ARM:?set ARM}"
export HIP_VISIBLE_DEVICES=6,7
unset ROCR_VISIBLE_DEVICES CUDA_VISIBLE_DEVICES
cd "$TREE"
.venv/bin/python -S - <<'PY'
import urllib.request,time
for _ in range(240):
 try:
  urllib.request.urlopen('http://127.0.0.1:18766/health',timeout=2).close();break
 except Exception:time.sleep(2)
else:raise RuntimeError('server readiness timeout')
PY
mkdir -p "$ROOT/mixed/$ARM"
.venv/bin/python -S tools/rdna/port_v031/stall_probe.py --base-url http://127.0.0.1:18766 --model flash-next --out "$ROOT/mixed/$ARM" --scenarios solo,inject --repeats 2 --seed 24683 --salt 777 --decoders 4 --decoder-prompt-tokens 8192 --decoder-max-tokens 4096 --warmup-tokens 16 --baseline-s 5 --prefill-lens 1024,16384 --inject-max-tokens 128 --recover-s 3 --steady-timeout-s 240 --request-timeout-s 600 --server-log "$ROOT/mixed-${ARM}-serve.log" --timeline
.venv/bin/python -S - <<'PY'
import urllib.request,json,os
from pathlib import Path
req=urllib.request.Request('http://127.0.0.1:18766/collective_rpc',data=json.dumps({'method':'rdna_kv_snapshot_layout'}).encode(),headers={'Content-Type':'application/json'})
with urllib.request.urlopen(req,timeout=60) as response:layout=json.load(response)
(Path('/home/chenco_adm/w4a8_runs/moe-offload/tiered-first-pass/mixed')/os.environ['ARM']/'kv-layout.json').write_text(json.dumps(layout,indent=2)+'\n')
PY
